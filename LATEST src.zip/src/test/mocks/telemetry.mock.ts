import { vi } from 'vitest';

export const track = vi.fn();
