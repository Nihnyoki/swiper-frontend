// src/person/dto/ifath.dto.ts
import { ApiProperty } from '@nestjs/swagger';

export class Ifath {
    name: string;
    date: string;
    tyte: string;
    data: string;
    path: string;
}
