/// <reference types="vite/client" />

declare const __WB_MANIFEST: Array<any>;