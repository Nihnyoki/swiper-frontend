import { FamilyTreeSlider } from "@/features/family-tree/components/FamilyTreeSlider";

/**
 * LEGACY COMPATIBILITY WRAPPER
 *
 * This component exists ONLY to preserve old imports.
 * It must not contain logic.
 */
export default function PreferedFamilyTreeSlider() {
  return <FamilyTreeSlider />;
}
