import { useFamilyTree } from "../features/family-tree/hooks/useFamilyTree";


const {
  activePerson,
  children,
  goToChild,
  goToParent,
} = useFamilyTree();
