import { precacheAndRoute } from 'workbox-precaching';

precacheAndRoute(__WB_MANIFEST);
