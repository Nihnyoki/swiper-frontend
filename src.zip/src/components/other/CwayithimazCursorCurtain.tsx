import React, { useEffect, useState } from "react";

interface CwayithimazCursorCurtainProps {

}

export function CwayithimazCursorCurtain(){ 
    
}
