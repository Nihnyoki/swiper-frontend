export class Things {
    key: number;
    val: string;
    childItems: object[];
}
